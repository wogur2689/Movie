package com.plnc.mngr.statistics.service.impl;

import java.util.HashMap;
import java.util.List;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.mngr.mber.service.MberManageVO;
import com.plnc.mngr.mngr.service.MngrManageVO;
import com.plnc.mngr.statistics.service.StatisticsVO;

@OracleMapper("StatisticsDAO")
public interface StatisticsDAO {

	/***
	 * 일 회원 통계
	 * @return
	 * @throws Exception
	 */
	public List<StatisticsVO> dayStatisticsList(StatisticsVO vo) throws Exception;
	
	/***
	 * 월 회원 통계
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Object> monthStatisticsList(StatisticsVO vo) throws Exception;
	
	/***
	 * 연도 회원 통계
	 * @return
	 * @throws Exception
	 */
	public List<StatisticsVO> yearStatisticsList(StatisticsVO vo) throws Exception;
	
	/***
	 * 일 누적 회원 통계
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Object> dayStatisticsAccmltList(StatisticsVO vo) throws Exception;
	
	/***
	 * 월 누적 회원 통계
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Object> monthStatisticsAccmltList(StatisticsVO vo) throws Exception;
	
	/***
	 * 연도 누적 회원 통계
	 * @return
	 * @throws Exception
	 */
	public HashMap<String, Object> yearStatisticsAccmltList(StatisticsVO vo) throws Exception;

}
