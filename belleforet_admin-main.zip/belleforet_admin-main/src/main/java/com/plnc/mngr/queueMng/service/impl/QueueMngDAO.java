package com.plnc.mngr.queueMng.service.impl;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.mngr.queueMng.service.QueueMngVO;

import java.util.List;
import java.util.Map;

@OracleMapper("QueueMngDAO")
public interface QueueMngDAO {

	List<QueueMngVO> waitingList() throws Exception;
	void updateWaitingList(Map<String, String> map) throws Exception;
	void updateOpTime(Map<String, String> map) throws Exception;
}
