package com.plnc.mngr.tckSls.service;

import com.plnc.cmmn.CmmnMngrVO;

public class TckSlsVO extends CmmnMngrVO {

	/* ================[팝업 호출 필수값 ]================ */
	private String tckSls; //

	public String getTckSls() {
		return tckSls;
	}

	public void setTckSls(String tckSls) {
		this.tckSls = tckSls;
	}

	/* ================[팝업 호출 필수값 End]================ */

}
