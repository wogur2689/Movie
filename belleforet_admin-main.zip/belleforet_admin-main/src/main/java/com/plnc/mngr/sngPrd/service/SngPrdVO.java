package com.plnc.mngr.sngPrd.service;

import java.util.List;

import com.plnc.cmmn.CmmnMngrVO;

public class SngPrdVO extends CmmnMngrVO {

	private String viewType;
	private String sngPrd;
	private String prePageParam;
	
	public String getPrePageParam() {
		return prePageParam;
	}
	public void setPrePageParam(String prePageParam) {
		this.prePageParam = prePageParam;
	}
	public String getViewType() {
		return viewType;
	}
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	public String getSngPrd() {
		return sngPrd;
	}
	public void setSngPrd(String sngPrd) {
		this.sngPrd = sngPrd;
	}

	
}
