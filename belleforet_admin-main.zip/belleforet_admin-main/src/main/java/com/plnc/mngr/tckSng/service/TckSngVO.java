package com.plnc.mngr.tckSng.service;

import java.util.List;

import com.plnc.cmmn.CmmnMngrVO;

public class TckSngVO extends CmmnMngrVO {

	private String viewType;
	private String tckSng;
	private String prePageParam;
	
	public String getPrePageParam() {
		return prePageParam;
	}
	public void setPrePageParam(String prePageParam) {
		this.prePageParam = prePageParam;
	}
	public String getViewType() {
		return viewType;
	}
	public void setViewType(String viewType) {
		this.viewType = viewType;
	}
	public String getTckSng() {
		return tckSng;
	}
	public void setTckSng(String tckSng) {
		this.tckSng = tckSng;
	}

	
}
