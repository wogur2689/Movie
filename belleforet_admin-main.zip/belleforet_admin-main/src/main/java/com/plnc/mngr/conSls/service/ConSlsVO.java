package com.plnc.mngr.conSls.service;

import com.plnc.cmmn.CmmnMngrVO;

public class ConSlsVO extends CmmnMngrVO {
	
	/* ================[팝업 호출 필수값 ]================ */
	
	private String conSls;
	
	public String getConSls() {
		return conSls;
	}
	
	public void setConSls(String conSls) {
		this.conSls = conSls;
	}
	
	/* ================[팝업 호출 필수값 End]================ */
}
