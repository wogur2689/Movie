package com.plnc.mngr.grpPrd.service;

import java.util.List;

import com.plnc.cmmn.CmmnMngrVO;

public class GrpPrdVO extends CmmnMngrVO {

	private String prePageParam;		// 이전 페이지

	public String getPrePageParam() {
		return prePageParam;
	}
	public void setPrePageParam(String prePageParam) {
		this.prePageParam = prePageParam;
	}



	
}
