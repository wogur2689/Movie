package com.plnc.cmmn.crypt;

public class PasswordCryptManager {

	public static void main(String[] args) throws Exception {
		System.out.println(BCryptManager.getInstance().encode("1234"));
	}
}
