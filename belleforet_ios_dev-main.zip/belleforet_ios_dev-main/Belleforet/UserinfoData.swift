//
//  UserinfoData.swift
//  Belleforet
//
//  Created by Klim mac on 2022/03/25.
//

import Foundation

class UserInfoData {
    static let shared = UserInfoData()
    
    var userName = ""
    var userId = ""
    var userMembershipLV = ""
    var isLogin = false
    var resno = ""
    
    private init() {}
}
