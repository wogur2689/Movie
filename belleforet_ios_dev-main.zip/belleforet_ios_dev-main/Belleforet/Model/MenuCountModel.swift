//
//  MenuCountModel.swift
//  Belleforet
//
//  Created by Klim Solution on 2023/02/01.
//

import Foundation

enum MenuCountModel {
    
    struct MenuCount: Codable {
        var myTicketCnt: Int
        var myCondoCnt: Int
        var myGolfCnt: Int
        
        init() {
            myTicketCnt = 0
            myCondoCnt = 0
            myGolfCnt = 0
        }
    }
}
