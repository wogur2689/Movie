//
//  APIModel.swift
//  RxSwiftTest
//
//  Created by Klim mac on 2021/12/14.
//

import Foundation

enum IntroModel {
    
    struct Appversion: Codable {
        var device: String
        var version: String
        var force_update: Bool
        
        init() {
            device = ""
            version = ""
            force_update = true
        }
    }
}
