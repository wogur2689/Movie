//
//  APIModel.swift
//  RxSwiftTest
//
//  Created by Klim mac on 2021/12/14.
//

import Foundation

enum UserInfoMoel {
    
    struct UserInfo: Codable {
        var birthDay: String
        var email: String
        var seUserNm: String?
        
        init() {
            birthDay = ""
            email = ""
            seUserNm = ""

        }
    }
}
