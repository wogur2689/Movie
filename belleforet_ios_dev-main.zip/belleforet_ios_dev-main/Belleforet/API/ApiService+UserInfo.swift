//
//  AosuService+SideMenu.swift
//  Belleforet
//
//  Created by Klim mac on 2022/02/22.
//

import Foundation
import RxSwift

extension ApiService {
    
    func getUserInfo() -> Observable<UserInfoMoel.UserInfo> {
        return sendRequest(endpoint: UserInfo.getUserInfo)
    }
    
}
