//
//  AosuService+SideMenu.swift
//  Belleforet
//
//  Created by Klim mac on 2022/02/22.
//

import Foundation
import RxSwift

extension ApiService {
    
    func getAppVersion() -> Observable<IntroModel.Appversion> {
        return sendRequest(endpoint: Intro.getAppVersion)
    }
    
}
