//
//  ApiService+MenuCount.swift
//  Belleforet
//
//  Created by Klim Solution on 2023/02/01.
//

import Foundation
import RxSwift

extension ApiService {
    
    func getMenuCount() -> Observable<MenuCountModel.MenuCount> {
        return sendRequest(endpoint: MenuCount.getMenuCount)
    }
    
}
