//
//  TopMenuCell.swift
//  Belleforet
//
//  Created by Klim mac on 2022/08/04.
//

import UIKit

class TopMenuCell: UITableViewCell {

    
    @IBOutlet weak var topMenuButton: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
