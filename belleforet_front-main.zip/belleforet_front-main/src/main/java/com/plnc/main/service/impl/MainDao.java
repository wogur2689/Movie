package com.plnc.main.service.impl;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.main.service.BasketProd;
import com.plnc.main.service.SertbFclt;
import com.plnc.main.service.SertbFcltDetail;
import com.plnc.main.service.SertbFcltDetailImage;
import egovframework.rte.psl.dataaccess.util.EgovMap;

import java.util.HashMap;
import java.util.List;

@OracleMapper("MainDao")
public interface MainDao {

	public List<SertbFclt> menuUnitTicketList(HashMap<String, Object> map) throws Exception;

	public List<SertbFclt> fcltWaiting() throws Exception;

	public List<SertbFclt> menuPkgTicketList(HashMap<String, Object> map) throws Exception;

	public List<SertbFclt> menuUnitTicketList4bus() throws Exception;

	public List<SertbFcltDetail> menuUnitTicketDetail(HashMap<String, Object> map) throws Exception;

	public List<SertbFcltDetail> menuPkgTicketDetail(HashMap<String, Object> map) throws Exception;

	public List<SertbFcltDetailImage> menuTicketDetailImage(HashMap<String, Object> map) throws Exception;

	public void basketProd(BasketProd prod) throws Exception;

	public Integer basketCnt(String userId) throws Exception;

	public List<EgovMap> waitingBatchData() throws Exception;

	public List<EgovMap> updateToBeforeOpening() throws Exception;

	public List<EgovMap> updateToOpening() throws Exception;

	public List<EgovMap> updateToClosed() throws Exception;

	public int updateWaitingStatus(HashMap<String, Object> map) throws Exception;
}