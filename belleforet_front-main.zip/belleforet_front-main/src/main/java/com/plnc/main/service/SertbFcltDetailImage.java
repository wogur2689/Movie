package com.plnc.main.service;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class SertbFcltDetailImage implements Serializable {

	private String url;
}