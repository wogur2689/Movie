package com.plnc.main.web;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.plnc.cmmn.PaymentUtil;
import com.plnc.main.service.MainService;
import com.plnc.main.service.PurchaseDto;
import com.plnc.main.service.VersionCheckDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api")
@CrossOrigin
public class MainRestController {

	@Resource
	private MainService mainService;

	/**
	 * app 버전 체크
	 */
	@GetMapping(value = "/update_check/{device_type}.ajax")
	public VersionCheckDto versionCheck(@PathVariable("device_type") String deviceType) throws Exception {
		log.info("deviceType = " + deviceType);
		String androidVersion = "1.2.0"; //android버전
		String iosVersion = "1.2.0"; //ios버전

		if(deviceType.equals("android")) { //android일경우
			return VersionCheckDto.builder()
					.device(deviceType)
					.version(androidVersion)
					.forceUpdate(true)
					.build();
		}
		else { //ios일 경우
			return VersionCheckDto.builder()
					.device(deviceType)
					.version(iosVersion)
					.forceUpdate(true)
					.build();
		}
	}

	/**
	 * 장바구니 담기 및 이동
	 */
	@GetMapping(value = "/purchase.ajax")
	public String purchase(HttpServletRequest request, @RequestParam HashMap<String, Object> map) {

		if (!PaymentUtil.isLogin(request)) {
			return "{\"result\": \"reqlogin\"}";
		}
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String json = new String(Base64.getDecoder().decode((String) map.get("query")));

		try {
			ObjectMapper mapper = new ObjectMapper();
			PurchaseDto req = mapper.readValue(json, new TypeReference<PurchaseDto>() {
			});

			// 회원아이디 추출
			log.info(">>> purchase.ajax / login user id = " + auth.getPrincipal());
			req.setMid((String) auth.getPrincipal());
			List<Object> obj = (List<Object>) req.getData();
			if (req.getSend().equals("basket")) {
				this.mainService.basketProd(req, obj);
			}
		}
		catch (Exception e) {
			e.printStackTrace();
			//TODO result vo로 개선
			return "{\"result\": \"fail\"}";
		}
		//TODO result vo로 개선
		return "{\"result\": \"success\"}";
	}
}