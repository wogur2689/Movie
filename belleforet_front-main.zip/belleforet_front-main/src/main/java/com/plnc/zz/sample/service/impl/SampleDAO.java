package com.plnc.zz.sample.service.impl;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.zz.sample.service.SampleVO;

@OracleMapper("SampleDAO")
public interface SampleDAO {
	
	/***
	 * 공지사항
	 */
	public int noticeInsert(SampleVO vo) throws Exception;
	
}
