package com.plnc.user.inqry.service;

import java.util.List;

public interface UserInqryService {

	/**
	 * 1:1 문의 조회
	 */
	public List<UserInqryVO> selectInqryList(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 등록
	 */
	public int insertInqry(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 수정
	 */
	public int updateInqry(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 상세
	 */
	public UserInqryVO selectInqryDatail(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 삭제
	 */
	public int deleteInqry(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 코드 조회
	 */
	public List<UserInqryVO> searchUserInqryClCd(UserInqryVO vo) throws Exception;
	

	
}
