package com.plnc.user.faq.service;

import com.plnc.cmmn.CmmnVO;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UserFaqVO extends CmmnVO {

	private String searchFaqSe;			// faq구분
	
	private String faqSn;				//faq 일련번호
	private String faqSj;				//faq 제목
	private String faqCn;				//faq 내용
	private String faqSe;				//faq 구분
	private String faqSeNm;				//faq 구분명
	private String useAt;				//사용여부
	private String searchText;			//검색
	private String searchType;			//검색
	private String searchFromDt;		// 가입일자 from
	private String searchToDt;			// 가입일자 to	
	private String isrtNm;				//등록자명
	private String updtNm;				//수정자 명
	private String clCd;				//faq구분 공통코드
	private String clNm;				//faq구분 코드명
}