package com.plnc.user.notice.service;

import java.util.List;
import java.util.Map;

public interface UserNoticeService {

	/**
	 * 공지사항 조회
	 */
	public List<UserNoticeVO> selectNoticeList(UserNoticeVO vo) throws Exception;
	
	/**
	 * 공지사항 팝업 조회
	 */
	public List<UserNoticeVO> selectNoticePopupList(UserNoticeVO vo) throws Exception;
	
	/**
	 * 공지사항 상세 조회
	 */
	public UserNoticeVO searchNoticeDetail(UserNoticeVO vo) throws Exception;
	
	/**
	 * 공지사항 파일 조회
	 */
	public List<UserNoticeVO> selectNoticeFile(UserNoticeVO vo) throws Exception;
	
	
}
