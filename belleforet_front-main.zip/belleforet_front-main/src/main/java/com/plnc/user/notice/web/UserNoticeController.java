package com.plnc.user.notice.web;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.plnc.cmmn.CmmnAppData;
import com.plnc.cmmn.CmmnController;
import com.plnc.main.service.MainService;
import com.plnc.user.notice.service.UserNoticeService;
import com.plnc.user.notice.service.UserNoticeVO;

@Controller
@RequestMapping("/user/notice")
public class UserNoticeController extends CmmnController {

	@Resource(name = "UserNoticeService")
	private UserNoticeService  userNoticeService;
	
	@Resource
	private MainService mainService;
	
	/**
	 * 공지 사항 page
	 */
	@RequestMapping("/noticeView.do")
	public String noticeView(@ModelAttribute("UserNoticeVO") UserNoticeVO vo, Model model) throws Exception {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String userId = (String) auth.getPrincipal();
		
		CmmnAppData app = CmmnAppData.builder().basket(this.mainService.basketCnt(userId)).menu("back").build();
		model.addAttribute("url_scheme", app);
		model.addAttribute("mParam", vo);
		return "user:/notice/noticeView";
	}

	/**
	 * 공지사항 조회
	 */
	@RequestMapping("/selectNoticeList.ajax")
	public String selectNoticeList(@ModelAttribute("UserNoticeVO") UserNoticeVO vo, Model model) throws Exception {
		model.addAttribute("result", userNoticeService.selectNoticeList(vo));
		model.addAttribute("pages", vo);
		return "jsonView";
	}
	
	/**
	 * 공지사항 팝업 조회
	 */
	@RequestMapping("/selectNoticePopupList.ajax")
	public String selectNoticePopupList(@ModelAttribute("UserNoticeVO") UserNoticeVO vo, Model model,HttpServletRequest request) throws Exception {
		model.addAttribute("result", userNoticeService.selectNoticePopupList(vo));
		model.addAttribute("file", userNoticeService.selectNoticeFile(vo));
		model.addAttribute("root", request.getRequestURL().toString().replace(request.getRequestURI(),""));
		return "jsonView";
	}
	
	/***
	 * 공지 사항 상세 page
	 */
	@RequestMapping("/noticeDetailView.do")
	public String noticeDetailView(@ModelAttribute("UserNoticeVO") UserNoticeVO vo, Model model) throws Exception {
		model.addAttribute("noticeSn", vo.getNoticeSn());
		model.addAttribute("mParam", vo);
		return "user:/notice/noticeDetail";
	}
	
	/***
	 * 공지사항 상세 조회
	 */
	@RequestMapping(value = "/selectNoticeView.ajax")
	public String selectNoticeView(@ModelAttribute("UserNoticeVO") UserNoticeVO vo, Model model,HttpServletRequest request) throws Exception {

		/* 상세 조회 */
		model.addAttribute("result", userNoticeService.searchNoticeDetail(vo));
		model.addAttribute("file", userNoticeService.selectNoticeFile(vo));
		
		model.addAttribute("root", request.getRequestURL().toString().replace(request.getRequestURI(),""));
		return "jsonView";
	}
	
	
}
