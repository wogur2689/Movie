package com.plnc.user.payMent.service;

import lombok.Data;

@Data
public class BillingCardVO {

	private int birSeq;
	private String billkey;
	private String cardNo;
	private String cardName;
	private String cardCode;
}
