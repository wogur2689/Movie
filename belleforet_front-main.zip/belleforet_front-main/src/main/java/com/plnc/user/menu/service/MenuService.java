package com.plnc.user.menu.service;

import java.util.List;

public interface MenuService {

	/**
	 * 사용자 앱 메뉴 목록 조회
	 */
	public List<MenuVO> getMobileMenuList ( MenuVO vo) throws Exception;
	

	
}
