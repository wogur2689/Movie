package com.plnc.user.faq.service.impl;

import java.util.List;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.user.faq.service.UserFaqVO;

@OracleMapper("UserFaqDAO")
public interface UserFaqDAO {

	/**
	 * Faq 목록 조회
	 */
	public List<UserFaqVO> searchUserFaqList(UserFaqVO vo) throws Exception;
	
	/**
	 * Faq 코드 조회
	 */
	public List<UserFaqVO> searchUserFaqClCd(UserFaqVO vo) throws Exception;
	
}
