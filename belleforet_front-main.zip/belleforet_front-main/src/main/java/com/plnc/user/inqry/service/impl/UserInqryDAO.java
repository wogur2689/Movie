package com.plnc.user.inqry.service.impl;

import java.util.List;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.user.inqry.service.UserInqryVO;

@OracleMapper("UserInqryDAO")
public interface UserInqryDAO {

	/**
	 * 1:1 문의 조회
	 */
	public List<UserInqryVO> selectInqryList(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 등록
	 */
	public int insertInqry(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 히스토리 저장
	 */
	public int insertInqryHist(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 수정
	 */
	public int updateInqry(UserInqryVO vo) throws Exception;
	/**
	 * 1:1 문의 상세 수정
	 */
	public UserInqryVO selectInqryDatail(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 삭제
	 */
	public int deleteInqry(UserInqryVO vo) throws Exception;
	
	/**
	 * 1:1 문의 관리자 이메일 조회
	 */
	public String inqryMngrEmail(String inqrySe) throws Exception;
	
	/**
	 * 1:1 문의 공통코드 조회
	 */
	public List<UserInqryVO> searchUserInqryClCd(UserInqryVO vo) throws Exception;
}
