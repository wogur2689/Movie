package com.plnc.user.mypage.service;

import java.util.List;

public interface MypageService {

	
	/**
	 * 회원 조회
	 */
	public int mberChk(MypageVO vo) throws Exception;
	
	/**
	 * 미사용티켓조회
	 */
	public int unusedTicketCnt(MypageVO vo) throws Exception;
	
	/**
	 * 번호 체크
	 */
	public int selectUserHandphoneCheck(MypageVO vo) throws Exception;
	
	/**
	 * 회원탈퇴
	 */
	public int deleteMberSecsn(MypageVO vo) throws Exception;
	
	/**
	 * 기본정보
	 */
	public MypageVO myInfoData(MypageVO vo) throws Exception;
	
	/**
	 * 비밀번호 체크
	 */
	public int myInfoPassword(MypageVO vo) throws Exception;
	
	/**
	 * 기본정보 수정
	 */
	public int myInfoUpdt(MypageVO vo) throws Exception;
	
	/**
	 * 장바구니
	 */
	public List<MypageVO> searchMypageWishList(MypageVO vo) throws Exception;
	
	/**
	 * 장바구니 수량 업데이트
	 */
	public int wishListUpdate(MypageVO vo) throws Exception;
	
	/**
	 * 장바구니 삭제
	 */
	public int wishListDelete(MypageVO vo) throws Exception;
}
