package com.plnc.user.event.service;

import java.util.List;

public interface UserEventService {

	/**
	 * 이벤트 조회
	 */
	public List<UserEventVO> selectEventList(UserEventVO vo) throws Exception;
	
	/**
	 * 이벤트 팝업 조회
	 */
	public List<UserEventVO> selectEventPopupList(UserEventVO vo) throws Exception;
	
	/**
	 * 이벤트 상세 조회
	 */
	public UserEventVO searchEventDetail(UserEventVO vo) throws Exception;
	
	/**
	 * 이벤트 파일 조회
	 */
	public List<UserEventVO> selectEventFile(UserEventVO vo) throws Exception;
	
	
}
