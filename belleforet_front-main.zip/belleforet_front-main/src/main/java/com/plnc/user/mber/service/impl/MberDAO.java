package com.plnc.user.mber.service.impl;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.user.mber.service.MberVO;

@OracleMapper("MberDAO")
public interface MberDAO {

	/**
	 * 아이디 중복 확인
	 */
	public int selectUserIdCheck(String userId) throws Exception;
	
	/**
	 * 휴대폰번호 중복 확인
	 */
	public int selectUserHandphoneCheck(MberVO vo) throws Exception;
	
	/**
	 * 회원번호 확인
	 */
	public int selectUserMemberNoCheck(MberVO vo) throws Exception;
	
	/**
	 * 회원번호 2중 확인
	 */
	public int selectUserMemberNoTwoCheck(MberVO vo) throws Exception;
	
	/**
	 * 기존회원가입자 업데이트
	 */
	public int mberSingupUpdate(MberVO vo) throws Exception;
	
	/**
	 * resno 번호
	 */
	public String selectUserResno(MberVO vo) throws Exception;
	
	/**
	 * ser 회원번호
	 */
	public String selectUserMemberNo(MberVO vo) throws Exception;
	
	/**
	 * 회원가입
	 */
	public int mberSingup(MberVO vo) throws Exception;
	
	/**
	 * 회원가입 중복 체크
	 */
	public int mberSingupOverlap(MberVO vo) throws Exception;
	
	/**
	 * 사용자 기본 정보 조회
	 */
	public MberVO mberInfo ( MberVO vo ) throws Exception;

	/**
	 * 아이디 찾기
	 */
	public String myIdFind(MberVO vo) throws Exception;
	
	/**
	 * 비밀번호 찾기
	 */
	public int myPwdFind(MberVO vo) throws Exception;
	
	/**
	 * 비밀번호 재설정
	 */
	public int myPwdReset(MberVO vo) throws Exception;

	/**
	 * 로그인 이력 저장
	 */
	public int loginHistInsert(MberVO vo) throws Exception;
	
}
