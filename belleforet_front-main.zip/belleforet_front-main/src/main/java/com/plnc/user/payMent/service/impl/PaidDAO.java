package com.plnc.user.payMent.service.impl;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.user.payMent.service.PaidVO;
import com.plnc.user.payMent.vo.OrderTicketVO;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@OracleMapper("PaidDAO")
public interface PaidDAO {
    int insertPaid(Map<String, Object> map) throws Exception;
    int updatePaid(Map<String, Object> map) throws Exception;
    int selectMaxCancelSequence(@Param("ipPurNo") String ipPurNo) throws Exception;
    int insertPaidVoid(Map<String, Object> map) throws Exception;

    void updateExpireDateTckState (Map<String, Object> map) throws Exception;

    int updatePaidRefOne(Map<String, Object> map) throws Exception;

    PaidVO selectPaidCondoInfo(String orderNo) throws Exception;

    String selectUserHandPhoneTwo(String resNo) throws Exception;
}
