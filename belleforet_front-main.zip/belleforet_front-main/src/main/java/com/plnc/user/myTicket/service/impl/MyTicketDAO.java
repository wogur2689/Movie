package com.plnc.user.myTicket.service.impl;

import java.util.List;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.user.myTicket.service.MyBuyTicketVO;
import com.plnc.user.myTicket.service.MyTicketVO;
import org.apache.ibatis.annotations.Param;

@OracleMapper("MyTicketDAO")
public interface MyTicketDAO {
	
	List<MyTicketVO> myTicketList(MyTicketVO vo) throws Exception;
	List<MyBuyTicketVO> listBuyTicket(@Param("userId")  String userId, @Param("tkState") String tkState) throws Exception;
}
