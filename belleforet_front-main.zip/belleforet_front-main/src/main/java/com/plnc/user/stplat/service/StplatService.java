package com.plnc.user.stplat.service;

import java.util.List;

public interface StplatService {

	/**
	 * 약관목록 조회
	 */
	public List<StplatVO> userStplatListView() throws Exception;
	
	
	/***
	 * 약관 조회
	 */
	public StplatVO searchStplat(StplatVO vo) throws Exception;
	
}
