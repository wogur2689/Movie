package com.plnc.user.mber.service;

public interface MberService {

	/**
	 * 아이디 중복 확인
	 */
	public int searchUserIdCheck(String userId) throws Exception;
	
	/**
	 * 휴대폰 중복 확인
	 */
	public int searchUserPhoneCheck(MberVO vo) throws Exception;
	
	 /**
	  * 회원가입
	  */
	public int mberSingup(MberVO vo) throws Exception;
	
	/**
	 * 아이디 찾기
	 */
	public String myIdFind(MberVO vo) throws Exception;
	
	/**
	 * 비밀번호 찾기
	 */
	public int myPwdFind(MberVO vo) throws Exception;
	
	/**
	 * 비밀번호 재설정
	 */
	public int myPwdReset(MberVO vo) throws Exception;

	/**
	 * 비밀번호 재설정
	 */
	public int loginHistInsert(MberVO vo) throws Exception;

}
