package com.plnc.cmmn.script.service.impl;

import com.plnc.cmmn.mapper.OracleMapper;
import com.plnc.cmmn.script.service.SmsAtalk;
import com.plnc.cmmn.script.service.SmsCertVO;

@OracleMapper("ScriptDAO")
public interface ScriptDAO {


	/**
	 * 휴대폰 이력 저장
	 */
	public int smsCert(SmsCertVO vo) throws Exception;

	/**
	 * 휴대폰 번호 인증 일치여부
	 */
	public int smsCertSameMatch(SmsCertVO vo) throws Exception;

	/**
	 * 휴대폰 번호 인증 업데이트
	 */
	public int smsCertSameMatchUpdate(SmsCertVO vo) throws Exception;

	/***
	 * SMS 발송(인증번호)
	 */
	public int smsSand(SmsCertVO vo) throws Exception;

	/***
	 * MMS 발송
	 */
	public int mmsSand(SmsCertVO vo) throws Exception;

	/***
	 * 알림톡 발송
	 */
	public void insertAtalkMsg(SmsAtalk vo) throws Exception;
}
