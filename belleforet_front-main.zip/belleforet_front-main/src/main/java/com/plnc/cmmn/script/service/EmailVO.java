package com.plnc.cmmn.script.service;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class EmailVO {
	private String email;		// 이메일
	private String subject;		// 제목
	private String contents;	// 내용
}
