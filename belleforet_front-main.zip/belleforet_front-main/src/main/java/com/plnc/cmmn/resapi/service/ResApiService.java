package com.plnc.cmmn.resapi.service;

import java.util.Map;

public interface ResApiService {
	
	int insertResApi(Map<String, Object> map) throws Exception;

}
