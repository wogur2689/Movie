package com.plnc.cmmn.fileUtil.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.multipart.MultipartFile;

import com.plnc.cmmn.script.service.AttachVO;

public interface CmmnFileSaveService {
	
	/**
	 * Request 던지고 List로 결과 받을시
	 */
	public List<Map<String, Object>>  saveFindNameMultipartFiles(HttpServletRequest req, final String dir, final String uploadNm) throws Exception;
	
	/**
	 * 업로드 후 DB에 저장하고 Key를 받을경우 1건리아도 List드림
	 */
	public Map<String, List<String>>  saveFileResultKey(HttpServletRequest req, final String dir, final String uploadNm) throws Exception;
	
	/**
	 */
	public String saveFileList(List<MultipartFile> fileList, final String dir, final String fileGrpSe, final String pFileGrpSn) throws Exception;
	
	/***
	 * 파일의 Contents를 꺼낼때
	 */
	public String readFileContent(String path) throws Exception;
	
	/***
	 * 파일 저장 - 1건씩
	 */
	public Map<String, Object> saveFile(MultipartFile file, String sOptionalPath) throws Exception;
	
	/***
	 * 파일 저장 - 다중
	 */
	public List<Map<String, Object>> saveFileMulti(MultipartFile[] file, String sOptionalPath) throws Exception;
	
	/***
	 * 파일 삭제시
	 */
	public void deleteFile(String fileUrl) throws Exception;
	
	/***
	 * 파일 삭제시
	 */
	public void deleteFile(String fileGrpSn, String fileSn) throws Exception;
	
	/***
	 * 파일 삭제 전체
	 */
	public void deleteFileAll(String fileGrpSn) throws Exception;
	
	/***
	 * 파일 목록 조회
	 */
	public List<AttachVO> searchFileList(final String fileGrpSn) throws Exception;
	
}
